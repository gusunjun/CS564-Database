drop table if exists Item;
drop table if exists Users;
drop table if exists Bid;
drop table if exists Sell;
drop table if exists Category;

CREATE TABLE Item (
	ItemID Integer PRIMARY KEY,
	Name varCHAR(30),
	Currently CHAR(15),
	Number_of_Bids INTEGER,
	Started CHAR(20),
	Ends CHAR(20),
	Location CHAR(15),
	Country CHAR(15),
	Description TEXT
);

CREATE TABLE Bid (
	ItemID CHAR(15),
	BidderID CHAR(15),
	Time CHAR(20),
	Amount CHAR(20),
    PRIMARY KEY(BidderID,ItemID,Time),
	FOREIGN KEY(BidderID)
		REFERENCES Users(UserID),
    FOREIGN KEY(ItemID)
		REFERENCES Item(ItemID)
);

CREATE TABLE Sell (
	SellerID CHAR(15),
    ItemID CHAR(15),
	Buy_Price CHAR(15),
	First_Bid CHAR(15),
    PRIMARY KEY(SellerID,ItemID),
    FOREIGN KEY(ItemID)
		REFERENCES Item(ItemID),
	FOREIGN KEY(SellerID)
		REFERENCES Users(UserID)
);

CREATE TABLE Users (
    UserID CHAR(15) PRIMARY KEY,
    Rating INTEGER,
	Location CHAR(15),
	Country CHAR(15)
	
);

CREATE TABLE Category (
    ItemID CHAR(20),
	Catname CHAR(15),
	PRIMARY KEY(ItemId, Catname)
	FOREIGN KEY(ItemID)
		REFERENCES Item(ItemID)
);
