SELECT COUNT(*)
FROM Users
WHERE location = "New York";