python skeleton_parser.py items-*.json

sort item.dat | uniq > item_uniq.dat
sort bid.dat | uniq > bid_uniq.dat
sort category.dat | uniq > category_uniq.dat
sort user.dat | uniq > user_uniq.dat
sort sellby.dat | uniq > sellby_uniq.dat
