/**
 * @author See Contributors.txt for code contributors and overview of BadgerDB.
 *
 * @section LICENSE
 * Copyright (c) 2012 Database Group, Computer Sciences Department, University of Wisconsin-Madison.
 */

#include <memory>
#include <iostream>
#include "buffer.h"
#include "exceptions/buffer_exceeded_exception.h"
#include "exceptions/page_not_pinned_exception.h"
#include "exceptions/page_pinned_exception.h"
#include "exceptions/bad_buffer_exception.h"
#include "exceptions/hash_not_found_exception.h"


 /**
  * The BufMgr class is the heart of the buffer manager,managing the buffer pool
  * including frame allocation and deallocation to pages in the file.
  * On this file, we implement clock algorithm by readPage, unPinPage, allocPage,
  * disposePage and flushFile functions.
  *
  *
  * @author Yuting Yan, Jinhan Zhu, Sunjun Gu
  * @9081211824,9081717150,9081574338
  */
namespace badgerdb {

    //----------------------------------------
    // Constructor of the class BufMgr
    //----------------------------------------

    BufMgr::BufMgr(std::uint32_t bufs)
        : numBufs(bufs) {
        bufDescTable = new BufDesc[bufs];

        for (FrameId i = 0; i < bufs; i++)
        {
            bufDescTable[i].frameNo = i;
            bufDescTable[i].valid = false;
        }

        bufPool = new Page[bufs];

        int htsize = ((((int)(bufs * 1.2)) * 2) / 2) + 1;
        hashTable = new BufHashTbl(htsize);  // allocate the buffer hash table

        clockHand = bufs - 1;
    }

    /**
     * Destructor of BufMgr class.
     * Flushes out all dirty pages and deallocates the buffer pool and the BufDesc table.
     */
    BufMgr::~BufMgr() {
        //run all the pages, flush out those dirty, valid and notpinned pages.
        for (std::uint32_t i = 0; i < numBufs; i++) {
            if (bufDescTable[i].dirty && !bufDescTable[i].pinCnt && bufDescTable[i].valid) {
                flushFile(bufDescTable[i].file);
            }
        }

        //free dynamically allocated memory for different structures
        delete hashTable;
        delete[] bufPool;
        delete[] bufDescTable;


    }

    /**
     * Advance clock to next frame in the buffer pool.
     */
    void BufMgr::advanceClock()
    {
        //move the clock hand to next frame in clockwise fashion
        clockHand = (clockHand + 1) % numBufs;
    }

    /**
     * Allocates a free frame using the clock algorithm;
     * if necessary, writing a dirty page back to disk. This private method will get
     * called by the readPage() and allocPage() methods described below.
     * If the buffer frame allocated has a valid page in it, remove the appropriate
     * entry from the hash table.
     *
     * @para frame reference, frame ID of allocated frame returned via this variable
     * @throw BufferExceededException if all buffer frames are pinned,
     *        no such buffer is found which can be allocated.
     */
    void BufMgr::allocBuf(FrameId & frame)
    {

        //declare a variable to record the status of pinned page
        bool pinned_flag = true;
        std::uint32_t count = 0;

        while (pinned_flag) {
            //if all buffer frames are pinned, throw expection.
            if (count == numBufs) {
                throw BufferExceededException();
            }
            // if the frame is valid
            if (bufDescTable[clockHand].valid) {
                // if the frame is recently referenced,update refbit and go next
                if (bufDescTable[clockHand].refbit) {
                    bufDescTable[clockHand].refbit = false;
                    advanceClock();
                    continue;
                }
                //if the frame is pinned, update count and go next
                if (bufDescTable[clockHand].pinCnt > 0) {
                    count++;
                    advanceClock();
                    continue;
                }
                //if the frame id dirty, write page back to file
                if (bufDescTable[clockHand].dirty) {
                    bufDescTable[clockHand].file->writePage(bufPool[clockHand]);

                }
                //remove the entry for the hashtable and clear the frame
                hashTable->remove(bufDescTable[clockHand].file,
                bufDescTable[clockHand].pageNo);
                bufDescTable[clockHand].Clear();
                //set the current clockHand to the frame and reset pinned_flag
                frame = clockHand;
                pinned_flag = false;
            }
            //if the frame is not valid, allocate from buffer pool and reset pinned_flag
            else {
                frame = clockHand;
                bufDescTable[clockHand].Clear();
                pinned_flag = false;

            }
        }
    }

    /**
     * Reads the given page from the file into a frame and returns the pointer to page.
     * If requested page is already present in buffer pool pointer to that frame is returned
     * otherwise a new frame is allocated from the buffer pool for reading the page.
     *
     * @para file File object
     * @para pageNo Page number in the file to be read
     * @para page Reference to page pointer.
     *       Used to fetch Page object in which requested page from file is read in.
     * @throw HashNotFoundException when page is not in the buffer pool,
     * on the hashtable to get a frame number.
     */
    void BufMgr::readPage(File* file, const PageId pageNo, Page*& page)
    {
        FrameId frameNo = 0;
        Page new_page;

        try {
            //Check if (file, pageNo) is currently in the buffer pool.
            hashTable->lookup(file, pageNo, frameNo);
            //If so, set refbit, increment the pinCnt for the frame,
            bufDescTable[frameNo].refbit = true;
            bufDescTable[frameNo].pinCnt++;
            //and then return a pointer to the frame
            page = &bufPool[frameNo];

        }
        catch (HashNotFoundException& e) {
            //If (file, pageNo) is not in the buffer pool, allocate a buffer frame
            allocBuf(frameNo);
            new_page = file->readPage(pageNo);
            bufPool[frameNo] = new_page;
            //insert the page into the hashtable and set it up
            hashTable->insert(file, pageNo, frameNo);
            bufDescTable[frameNo].Set(file, pageNo);
            //and then return a pointer to the frame
            page = &bufPool[frameNo];
        }

    }

    /**
     * Unpin a page from memory since it is no longer required for it to remain in memory.
     * Decrements the pinCnt of the frame containing (file, PageNo) and,
     * if dirty == true, sets the dirty bit.
     * Throws PAGENOTPINNED if the pin count is already 0. Does nothing if
     * page is not found in the hash table lookup.
     *
     * @param file File object
     * @param PageNo Page number
     * @param dirty True if the page to be unpinned needs to be marked dirty
     * @throw PAGENOTPINNED If the page is not already pinned.
     */
    void BufMgr::unPinPage(File* file, const PageId pageNo, const bool dirty)
    {
        FrameId frameNo;

        try {
            // check if (file, pageNo) is currently in the buffer pool.
            // if so, decrements the pinCnt and set the dirty bit.
            hashTable->lookup(file, pageNo, frameNo);
            if (bufDescTable[frameNo].pinCnt > 0) {
                bufDescTable[frameNo].pinCnt--;
                if (dirty) {
                    bufDescTable[frameNo].dirty = true;
                }
            }
            //if the pin count is 0, throw exception
            else {
                throw PageNotPinnedException(file->filename(), pageNo, frameNo);
            }

        }
        catch (HashNotFoundException& e) {

        }
    }

    /**
     * Allocate an empty page in specified file by invoking the file->allocatePage(),
     * return a newly allocated page.allocBuf() obtains a buffer pool frame.an entry
     * is inserted into the hash table and Set() is invoked.
     *
     * @param file File object
     * @param PageNo Page number. The number assigned to the page in the file is returned via this reference.
     * @param page Reference to page pointer. The newly allocated in-memory Page object is returned via this reference.
     */
    void BufMgr::allocPage(File* file, PageId &pageNo, Page*& page)
    {
        Page new_page;
        //allocate an empty page in the specified file
        new_page = file->allocatePage();
        pageNo = new_page.page_number();
        page = &new_page;
        //read the page from disk into the buffer pool frame
        readPage(file, pageNo, page);

    }

    /**
     * Writes out all dirty pages of the file to disk.
     * All the frames assigned to the file need to be unpinned from buffer pool before
     * this function can be successfully called. Otherwise Error returned.
     *
     * @param file File object
     * @throw PagePinnedException if any page of the file is pinned in the buffer pool
     * @throw BadBufferException if any frame allocated to the file is found to be invalid
     */
    void BufMgr::flushFile(const File* file)
    {
        //scan bufPool for pages belonging to the file
        for (std::uint32_t i = 0; i < numBufs; i++) {
            int frameNo = bufDescTable[i].frameNo;
            if (bufDescTable[i].file != NULL) {
                //find the page belong to the file
                if (bufDescTable[i].file == file) {
                    //throws PagePinnedException if some page of the file is pinned
                    if (bufDescTable[i].pinCnt != 0) {
                        throw PagePinnedException(file->filename(), bufDescTable[i].pageNo, frameNo);
                    }
                    //throws BadBufferException if an invalid page belonging to the file
                    else if (!bufDescTable[i].valid) {
                        throw BadBufferException(frameNo, bufDescTable[i].dirty,
                            bufDescTable[i].valid, bufDescTable[i].refbit);
                    }
                    //flush the dirty page to disk and set dirty bit
                    else if (bufDescTable[i].dirty) {
                        bufDescTable[i].file->writePage(bufPool[bufDescTable[i].frameNo]);
                        bufDescTable[i].dirty = false;
                    }
                    // remove flushed page
                    hashTable->remove(file, bufDescTable[i].pageNo);
                    //clear  BufDesc for the page frame
                    bufDescTable[i].Clear();
                }
            }

        }
    }


    /**
     * Deletes a particular page from file and also from buffer pool if present.
     * Since page is entirely deleted from file,unnecessary to see if page is dirty.
     * Before deleting page from file, it makes sure if the page deleted is
     * allocated a frame in the buffer pool,
     * that frame is freed and correspondingly entry from hash table is removed.
     *
     * @param file File object
     * @param PageNo Page number
     */
    void BufMgr::disposePage(File* file, const PageId PageNo)
    {
        FrameId frameNo;

        //Check if (file, pageNo) is currently in the buffer pool.
        //If so, free frame and correspondingly remove entry from hash table.
        try {
            hashTable->lookup(file, PageNo, frameNo);
            bufDescTable[frameNo].Clear();
            hashTable->remove(file, PageNo);
            file->deletePage(PageNo);
        }
        catch (HashNotFoundException& e) {
            //If not in buffer pool, still need to delete from file
            file->deletePage(PageNo);
        }

    }
    /**
     * Print information.
     */
    void BufMgr::printSelf(void)
    {
        BufDesc* tmpbuf;
        int validFrames = 0;

        for (std::uint32_t i = 0; i < numBufs; i++)
        {
            tmpbuf = &(bufDescTable[i]);
            std::cout << "FrameNo:" << i << " ";
            tmpbuf->Print();

            if (tmpbuf->valid == true)
                validFrames++;
        }

        std::cout << "Total Number of Valid Frames:" << validFrames << "\n";
    }

}




